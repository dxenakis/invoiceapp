
package com.invoiceapp.auth.dto;

public record SwitchCompanyRequest(Long companyId) {}
