
package com.invoiceapp.auth.dto;

public record AuthResponse(String token) {}
