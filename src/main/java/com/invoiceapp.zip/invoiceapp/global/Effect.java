package com.invoiceapp.global;

public enum Effect {
    INCREASE,    // αυξάνει
    DECREASE,    // μειώνει
    NEUTRAL      // αδιάφορο
}
