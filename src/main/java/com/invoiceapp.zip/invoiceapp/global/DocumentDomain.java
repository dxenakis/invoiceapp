package com.invoiceapp.global;

public enum DocumentDomain {
    PURCHASES,   // Αγορές
    SALES,       // Πωλήσεις
    COLLECTIONS,    // Εισπράξεις
    PAYMENTS     // Πληρωμές
}