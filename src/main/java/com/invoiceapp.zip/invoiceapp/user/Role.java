package com.invoiceapp.user;

public enum Role {
    ADMIN,
    COMPANY_ADMIN,
    ACCOUNTANT,
    VIEWER
}
